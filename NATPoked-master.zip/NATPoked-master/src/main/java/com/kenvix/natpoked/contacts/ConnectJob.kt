package com.kenvix.natpoked.contacts


sealed interface ConnectJob {

}