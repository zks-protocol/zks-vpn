//--------------------------------------------------
// Class NATTraversalKit
//--------------------------------------------------
// Written by Kenvix <i@kenvix.com>
//--------------------------------------------------

package com.kenvix.natpoked.client.traversal

@Deprecated("Use PortGuessUtils instead")
abstract class NATTraversalKit