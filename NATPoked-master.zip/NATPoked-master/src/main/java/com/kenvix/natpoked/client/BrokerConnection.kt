//--------------------------------------------------
// Interface BrokerConnection
//--------------------------------------------------
// Written by Kenvix <i@kenvix.com>
//--------------------------------------------------

package com.kenvix.natpoked.client

interface BrokerConnection {
}