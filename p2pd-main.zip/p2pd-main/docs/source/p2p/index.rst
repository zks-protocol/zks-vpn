Peer-to-peer networking
===========================

.. HINT::
    | For an interactive demo of P2PD's peer-to-peer networking features install
    | see the ":doc:`../built/demo`" page.

.. toctree::
    nodes
    nicknames
    connect
    msg_handling

