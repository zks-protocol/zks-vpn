from p2pd import *

async def workspace():
    pass

async_test(workspace)