python3 -m pip install sphinx==6.2.1
python3 -m pip install sphinx_rtd_theme==1.2.2
python3 -m pip install myst-parser==2.0.0
python3 -m pip install sphinx_rtd_theme==1.2.2
python3 -m pip install readthedocs-sphinx-search==0.3.
echo "Restart your terminal now!"
echo "On windows add the scripts dir to ur PATH = e.g. C:\Users\matth\AppData\Local\Programs\Python\Python310\Scripts"