sudo apt-get update
sudo apt-get install build-essential git screen net-tools python3-pip
sudo apt-get install g++
sudo apt-get install make
sudo apt-get install libboost-dev # For Boost
sudo apt-get install libssl-dev 

# Echo server, port 7, tcp, udp, v4/6
sudo apt-get install inetutils-inetd