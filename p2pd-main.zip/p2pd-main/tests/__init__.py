try:
    from p2pd.test_init import *
    from .static_route import *
except:
    from p2pd.test_init import *
    from static_route import *